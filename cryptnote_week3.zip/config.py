class Config:
    MONGO_URI = "mongodb://localhost:27017/cryptnote_db"
