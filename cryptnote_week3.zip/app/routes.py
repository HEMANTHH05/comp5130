from flask import Blueprint, request, jsonify
from app import mongo

main = Blueprint('main', __name__)

@main.route('/api/register', methods=['POST'])
def register():
    # Registration logic here
    data = request.json
    mongo.db.users.insert_one(data)
    return jsonify({"msg": "User registered successfully"}), 201

@main.route('/api/notes', methods=['POST'])
def create_note():
    # Note creation logic here
    data = request.json
    mongo.db.notes.insert_one(data)
    return jsonify({"msg": "Note created"}), 201
